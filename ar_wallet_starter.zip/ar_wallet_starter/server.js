const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("wallet-demo.db");
const PORT = process.env.PORT || 3000;

// Set these environment variables before using outside a local demo.
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@example.com";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "ChangeMe123!";
const SESSION_SECRET = process.env.SESSION_SECRET || "local-demo-secret-change-this";

app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user'
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    amount_inr INTEGER NOT NULL,
    upi_reference TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

const adminExists = db.prepare("SELECT id FROM users WHERE email = ?").get(ADMIN_EMAIL);
if (!adminExists) {
  const hash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
  db.prepare("INSERT INTO users(email, password_hash, role) VALUES (?, ?, 'admin')")
    .run(ADMIN_EMAIL, hash);
  console.log(`Demo admin created: ${ADMIN_EMAIL}. Change credentials before deployment.`);
}

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please log in first." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin")
    return res.status(403).json({ error: "Admin access required." });
  next();
}

app.post("/api/register", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password || String(password).length < 10)
    return res.status(400).json({ error: "Email and a password of at least 10 characters are required." });
  try {
    const hash = await bcrypt.hash(String(password), 12);
    db.prepare("INSERT INTO users(email, password_hash) VALUES (?, ?)").run(String(email).trim().toLowerCase(), hash);
    res.json({ ok: true });
  } catch {
    res.status(400).json({ error: "Could not create account. Email may already be registered." });
  }
});

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body || {};
  const user = db.prepare("SELECT id, email, password_hash, role FROM users WHERE email = ?")
    .get(String(email || "").trim().toLowerCase());
  if (!user || !(await bcrypt.compare(String(password || ""), user.password_hash)))
    return res.status(401).json({ error: "Invalid email or password." });
  req.session.user = { id: user.id, email: user.email, role: user.role };
  res.json({ ok: true, user: req.session.user });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/orders", requireAuth, (req, res) => {
  const amount = Number(req.body?.amount);
  const reference = String(req.body?.upiReference || "").trim();
  if (!Number.isInteger(amount) || amount < 1 || amount > 100000)
    return res.status(400).json({ error: "Amount must be between ₹1 and ₹100,000 for this demo." });
  const result = db.prepare("INSERT INTO orders(user_id, amount_inr, upi_reference) VALUES (?, ?, ?)")
    .run(req.session.user.id, amount, reference || null);
  res.json({ ok: true, orderId: result.lastInsertRowid, status: "pending",
    note: "Demo order only. Payment is not verified automatically." });
});

app.get("/api/orders", requireAuth, (req, res) => {
  const orders = req.session.user.role === "admin"
    ? db.prepare("SELECT orders.*, users.email FROM orders JOIN users ON users.id = orders.user_id ORDER BY orders.id DESC").all()
    : db.prepare("SELECT id, amount_inr, upi_reference, status, created_at FROM orders WHERE user_id = ? ORDER BY id DESC").all(req.session.user.id);
  res.json({ orders });
});

app.patch("/api/admin/orders/:id", requireAdmin, (req, res) => {
  const status = req.body?.status;
  if (!["approved", "rejected"].includes(status))
    return res.status(400).json({ error: "Status must be approved or rejected." });
  const result = db.prepare("UPDATE orders SET status = ? WHERE id = ?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Order not found." });
  res.json({ ok: true, status });
});

app.listen(PORT, () => console.log(`Demo running at http://localhost:${PORT}`));
