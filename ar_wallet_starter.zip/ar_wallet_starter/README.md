# AR Wallet Starter (Demo)

This is a small Node.js + SQLite demo with account registration/login, order submission, and admin approve/reject controls. It is **not** a production payment or cryptocurrency exchange.

## Run locally
1. Install Node.js 20+.
2. In this folder run: `npm install`
3. Start: `npm start`
4. Open `http://localhost:3000`

Demo admin login:
- Email: `admin@example.com`
- Password: `ChangeMe123!`

## Before any public deployment
- Replace demo admin credentials and set a long random `SESSION_SECRET`.
- Use HTTPS and secure cookie settings.
- Use a persistent, production-grade session store; add CSRF protection, rate limiting, email verification, password reset, audit logs, backups, and monitoring.
- Never store UPI PINs, OTPs, or bank credentials.
- Do not treat screenshots or user-entered UPI references as proof of payment. Integrate an authorized payment provider's server-side verification/webhooks.
- Get legal/compliance advice before offering crypto exchange, custody, wallet balances, or transfers. Do not display fictional balances or claim payments succeeded when unverified.
- This demo stores order records only. It does not process payments, issue ARB, or implement a sell/payout flow.
